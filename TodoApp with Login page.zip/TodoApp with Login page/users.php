<?php
ob_start();
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$get=file_get_contents('users.json');
$db_user=json_decode($get,1);
$email_user=$_POST['email_user'];
$password_user=$_POST['password_user'];
$emailcheck=array_column($db_user,'email'); 
$passwordcheck=array_column($db_user,'password');

if (isset($_POST['submit'])) {       
    if(in_array($email,$emailcheck)){        
        echo 'Registered before';    
    }

    else{
        $id=uniqid();        
        $db_user[]=[
            'name'=>$name,
            'email'=>$email,
            'password'=>$password,
            'id'=>$id
        ];
        file_put_contents('users.json',json_encode($db_user));
        setcookie('login',$id,time()+3600*24);        
        header('location: task.php');   
    }

}elseif($_POST['submit_user']){
    if(in_array($email_user,$emailcheck) and in_array($password_user,$passwordcheck)) {
        $index=array_search($email_user,$emailcheck);
        setcookie('login', $db_user[$index]['id'], time()+3600*24);
        header('location: task.php'); 
    }else{
        echo "Email or Password incorrect";
    }    
}

