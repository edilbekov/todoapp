<?php
// ob_start();  WHY???????
$gettask=file_get_contents('tasks.json');
$db_task=json_decode($gettask, 1);
$task=$_POST['task'];
$method = $_SERVER['REQUEST_METHOD'];
if($method==="POST"){
    if(isset($_POST['save'])){
        $ids=$_COOKIE['login'];
        $db_task[$ids][]=[        
            'task'=>$task, 
            'status'=>'In progress',             
            'id'=>uniqid()
        ];            
        file_put_contents('tasks.json',json_encode($db_task));
        header('location: task.php');
        exit();
    }    
}

if($method==="GET"){
    $type=$_GET['type'];
    $id=$_GET['id'];    
    if($type=='delete'){
        $idcolumn=array_column($db_task[$_COOKIE['login']],'id');
        $index=array_search($id,$idcolumn);                
        unset($db_task[$_COOKIE['login']][$index]); 
        file_put_contents('tasks.json',json_encode($db_task));       
        header('location: task.php');
        exit();
    }
    if($type=='finished'){
        $idcolumn=array_column($db_task[$_COOKIE['login']],'id');
        $index=array_search($id,$idcolumn);                
        $db_task[$_COOKIE['login']][$index]['status']='Finished';
        file_put_contents('tasks.json',json_encode($db_task));       
        header('location: task.php');
        exit();
    }
}
?>